diff <(./split a) <(./rsplit a $) > /dev/null

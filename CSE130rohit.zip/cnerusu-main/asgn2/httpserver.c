#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <regex.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "asgn2_helper_funcs.h"
#define BUFFER_SIZE 2048
char buffer[BUFFER_SIZE];
#define resp505                                                                                    \
    "HTTP/1.1 505 Version Not Supported\r\nContent-Length: 22\r\n\r\nVersion Not Supported\n"
#define resp403 "HTTP/1.1 403 Forbidden\r\nContent-Length: 10\r\n\r\nForbidden\n"
#define resp200 "HTTP/1.1 200 OK\r\nContent-Length: "
#define resp201 "HTTP/1.1 201 Created\r\nContent-Length: 8\r\n\r\nCreated\n"
#define resp500                                                                                    \
    "HTTP/1.1 500 Internal Server Error\r\nContent-Length: 22\r\n\r\nInternal Server Error\n"
#define resp501     "HTTP/1.1 501 Not Implemented\r\nContent-Length: 16\r\n\r\nNot Implemented\n"
#define resp400     "HTTP/1.1 400 Bad Request\r\nContent-Length: 12\r\n\r\nBad Request\n"
#define resp404     "HTTP/1.1 404 Not Found\r\nContent-Length: 10\r\n\r\nNot Found\n"
#define resp200_PUT "HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\nOK\n"

struct Request {
    char method[9];
    char uri[65];
    char version[9];
    char key[129];
    char value[129];
};
int extract_request(struct Request *r) {
    regex_t requestLine;
    regex_t headerField;
    regex_t messageBody;
    regmatch_t requestLine_match[4];
    regmatch_t headerField_match[3];
    regmatch_t messageBody_match[2];
    const char *requestLine_pattern
        = "^([a-zA-Z]{1,8}) /([a-zA-Z0-9.-]{1,63}) (HTTP/[0-9][.][0-9])\r\n";
    const char *headerField_pattern = "([a-zA-Z0-9.-]{1,128}): ([ -~]{1,128})\r\n";
    const char *messageBody_pattern = "\r\n(.*)";
    regcomp(&requestLine, requestLine_pattern, REG_EXTENDED);
    regcomp(&headerField, headerField_pattern, REG_EXTENDED);
    regcomp(&messageBody, messageBody_pattern, REG_EXTENDED);
    int res = regexec(&requestLine, buffer, 4, requestLine_match, 0);
    if (res != 0) {
        regfree(&requestLine);
        regfree(&headerField);
        regfree(&messageBody);
        return -2;
    }
    strncpy(r->method, buffer + requestLine_match[1].rm_so,
        requestLine_match[1].rm_eo - requestLine_match[1].rm_so);
    strncpy(r->uri, buffer + requestLine_match[2].rm_so,
        requestLine_match[2].rm_eo - requestLine_match[2].rm_so);
    strncpy(r->version, buffer + requestLine_match[3].rm_so,
        requestLine_match[3].rm_eo - requestLine_match[3].rm_so);
    char *cursor = buffer + requestLine_match[0].rm_eo;
    int finalpos = requestLine_match[0].rm_eo;
    for (; regexec(&headerField, cursor, 3, headerField_match, 0) == 0;
         cursor += headerField_match[0].rm_eo, finalpos += headerField_match[0].rm_eo) {
        if (strcmp(cursor, cursor + headerField_match[0].rm_so) != 0) {
            regfree(&requestLine);
            regfree(&headerField);
            regfree(&messageBody);
            return -1;
        }
        char multipleHeaders[129] = { 0 };
        strncpy(multipleHeaders, cursor + headerField_match[1].rm_so,
            headerField_match[1].rm_eo - headerField_match[1].rm_so);

        if (strcmp(multipleHeaders, "Content-Length") == 0) {
            strncpy(r->key, cursor + headerField_match[1].rm_so,
                headerField_match[1].rm_eo - headerField_match[1].rm_so);
            strncpy(r->value, cursor + headerField_match[2].rm_so,
                headerField_match[2].rm_eo - headerField_match[2].rm_so);
        }
    }

    if (regexec(&messageBody, cursor, 2, messageBody_match, 0) == 0
        && strcmp(cursor, cursor + messageBody_match[0].rm_so) == 0) {
        // Successful extraction and cursor position matches.
    } else {
        fprintf(stderr, "Failed to extract or validate message body.\n");
        regfree(&requestLine);
        regfree(&headerField);
        regfree(&messageBody);
        return -1;
    }
    regfree(&requestLine);
    regfree(&headerField);
    regfree(&messageBody);
    return finalpos + 2;
}

void filehand(int server_socket) {
    switch (errno) {
    case ENOENT: write_n_bytes(server_socket, resp404, strlen(resp404)); break;
    case EACCES: write_n_bytes(server_socket, resp403, strlen(resp403)); break;
    case EISDIR: write_n_bytes(server_socket, resp403, strlen(resp403)); break;
    default: write_n_bytes(server_socket, resp500, strlen(resp500)); break;
    }
}

void getfunc(int server_socket, int fd) {
    struct stat fileStat;
    fstat(fd, &fileStat);
    uint64_t filesize = fileStat.st_size;
    char fsize[129] = { "\0" };
    sprintf(fsize, "%lu", filesize);
    write_n_bytes(server_socket, resp200, strlen(resp200));
    write_n_bytes(server_socket, fsize, strlen(fsize));
    write_n_bytes(server_socket, "\r\n\r\n", 4);
    pass_n_bytes(fd, server_socket, filesize);
}

int transfer_data(int fd, int server_socket, int n) {
    char buffer[BUFFER_SIZE];
    int total_written = 0;
    while (n > 0) {
        int bytes_to_read;
        if (n < BUFFER_SIZE) {
            bytes_to_read = n;
        } else {
            bytes_to_read = BUFFER_SIZE;
        }
        int read_bytes = read(server_socket, buffer, bytes_to_read);
        if (read_bytes == 0) {
            fprintf(stderr, "End of stream reached or connection closed by client\n");
            break;
        }
        if (read_bytes < 0) {
            if (errno == EINTR)
                continue;
            perror("Read error");
            return -1;
        }

        int bytes_written = 0;
        while (bytes_written < read_bytes) {
            int write_bytes = write(fd, buffer + bytes_written, read_bytes - bytes_written);
            if (write_bytes < 0) {
                if (errno == EINTR)
                    continue;
                perror("Write error");
                return -1;
            }
            bytes_written += write_bytes;
        }

        total_written += bytes_written;
        n -= bytes_written;
    }
    return total_written;
}

void putfunc(
    int server_socket, struct Request *req, int fd, int before_msg, int readIn, bool new_f) {
    int content_length = atoi(req->value);
    int bytes_received = readIn - before_msg;
    int bytes_to_write = (content_length < bytes_received) ? content_length : bytes_received;
    int total_written = write_n_bytes(fd, buffer + before_msg, bytes_to_write);

    if (total_written < bytes_to_write) {
        fprintf(stderr, "error writing data to file\n");
    } else {
        fprintf(stderr, "Wrote %d bytes.\n", total_written);
    }

    if (content_length > bytes_received) {
        int remaining = content_length - bytes_received;
        int additional_written = transfer_data(fd, server_socket, remaining);
        if (additional_written != remaining) {
            fprintf(stderr, "Failed to retrieve.\n");
        } else {
            fprintf(stderr, "Additional %d bytes \n", additional_written);
        }
    }
    if (new_f) {
        write_n_bytes(server_socket, resp201, strlen(resp201));
    } else {
        write_n_bytes(server_socket, resp200_PUT, strlen(resp200_PUT));
    }
}

int filecheck(const char *path) {
    struct stat buf;
    if (stat(path, &buf) == -1) {
        return false;
    }
    return S_ISDIR(buf.st_mode) ? true : false;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return EXIT_FAILURE;
    }
    int port = atoi(argv[1]);
    if (port <= 0 || port > 65535) {
        fprintf(stderr, "Error\n");
        return EXIT_FAILURE;
    }
    Listener_Socket listener;
    int listening = listener_init(&listener, port);
    if (listening != 0) {
        fprintf(stderr, "Error\n");
        return EXIT_FAILURE;
    }

    while (true) {
        int server_socket = listener_accept(&listener);
        int read_in = read_until(server_socket, buffer, BUFFER_SIZE, "\r\n\r\n");
        char *delimiter_start = strstr(buffer, "\r\n\r\n");
        char *delimiter_end = delimiter_start + 4;
        if (!delimiter_end) {
            fprintf(stderr, "Delimiter not found\n");
        } else {
            size_t bytes_after_delimiter = strlen(delimiter_end);
            char *contents_after_delimiter = malloc(bytes_after_delimiter + 1);
            if (contents_after_delimiter) {
                strcpy(contents_after_delimiter, delimiter_end);
            } else {
                fprintf(stderr, "Allocation failed\n");
            }
        }
        struct Request r;
        memset(&r, 0, sizeof(struct Request));
        int before_message = extract_request(&r);
        bool shouldCloseConnection = false;
        if ((strcmp(r.method, "PUT") == 0 && strcmp(r.key, "Content-Length") != 0)
            || before_message == -2) {
            write_n_bytes(server_socket, resp400, strlen(resp400));
            memset(buffer, '\0', BUFFER_SIZE);
            read_n_bytes(server_socket, buffer, BUFFER_SIZE);
            shouldCloseConnection = true;
        }
        if (shouldCloseConnection) {
            close(server_socket);
            continue;
        }
        if (strncmp(r.method, "GET", strlen(r.method)) == 0
            || strncmp(r.method, "PUT", strlen(r.method)) == 0) {
            if (before_message < 0 || strcmp(r.version, "HTTP/1.1") != 0) {
                if (strcmp(r.version, "HTTP/1.1") != 0) {
                    write_n_bytes(server_socket, resp505, strlen(resp505));
                } else {
                    write_n_bytes(server_socket, resp400, strlen(resp400));
                }
                memset(buffer, '\0', BUFFER_SIZE);
                read_n_bytes(server_socket, buffer, BUFFER_SIZE - 1);
                close(server_socket);
                continue;
            } else if (strcmp(r.method, "GET") == 0) {
                if (filecheck(r.uri)) {
                    write_n_bytes(server_socket, resp403, strlen(resp403));
                    close(server_socket);
                    continue;
                }

                int fileDescriptor = open(r.uri, O_RDONLY);
                if (fileDescriptor == -1) {
                    filehand(server_socket);
                    memset(buffer, '\0', BUFFER_SIZE);
                    read_n_bytes(server_socket, buffer, BUFFER_SIZE - 1);
                    close(server_socket);
                    continue;
                }

                getfunc(server_socket, fileDescriptor);
                close(fileDescriptor);
            }

            else if (strcmp(r.method, "PUT") == 0) {
                if (strcmp(r.key, "Content-Length") != 0) {
                    write_n_bytes(server_socket, resp400, strlen(resp400));
                    memset(buffer, '\0', BUFFER_SIZE);
                    read_n_bytes(server_socket, buffer, BUFFER_SIZE - 1);
                    close(server_socket);
                    continue;
                }

                bool isNewFile = false;
                int fileDescriptor = open(r.uri, O_WRONLY | O_TRUNC, 0666);
                if (fileDescriptor == -1) {
                    fileDescriptor = open(r.uri, O_CREAT | O_WRONLY | O_TRUNC, 0666);
                    isNewFile = fileDescriptor != -1;
                }

                if (fileDescriptor == -1) {
                    filehand(server_socket);
                    close(server_socket);
                    continue;
                }

                putfunc(server_socket, &r, fileDescriptor, before_message, read_in, isNewFile);
                close(fileDescriptor);
            }

        } else {
            write_n_bytes(server_socket, resp501, strlen(resp501));
        }
        memset(buffer, '\0', BUFFER_SIZE);
        read_n_bytes(server_socket, buffer, BUFFER_SIZE - 1);
        close(server_socket);
    }
}
